create function date_part(text, date) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
select pg_catalog.date_part($1, cast($2 as timestamp without time zone))
$$;

comment on function date_part(text, date) is 'extract field from date';

alter function date_part(text, date) owner to postgres;

